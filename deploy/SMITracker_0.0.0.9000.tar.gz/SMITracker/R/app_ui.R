#' The application User-Interface
#'
#' @param request Internal parameter for `{shiny}`.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_ui <- function(request) {
  tagList(
    # Leave this function for adding external resources
    golem_add_external_resources(),
    # Your application UI logic
    fluidPage(
      tabsetPanel(
        tabPanel(title = "Loading data",
                 fluidRow(
                   column(2,
                          wellPanel(
                            h5(strong("Navigate to the location of json files (outputs of
                                      localization analysis in ThunderSTORM")),
                            br(),
                            h5("Dataset names should follow a common style carrying
                                      relevant information for each dataset"),
                            br(),
                            shinyDirButton(id = "folder",label = "Select input folder",
                                           title = "Navigate to the directory of json
                                           files produced as a result of localization
                                           analysis in ThunderSTORM" ),
                            br(),
                            br(),
                            textInput("sep", "_", label = "Separator of the dataset name parts"),

                            selectInput("checkGroup1",
                                        "Expr.conds with numeric values",
                                        choices = c("expr.cond1",
                                                    "expr.cond2",
                                                    "expr.cond3",
                                                    "expr.cond4",
                                                    "expr.cond5"), multiple = TRUE),
                            br(),
                            br(),
                            textInput("analysis.id", "Unique analysis ID"),
                            actionButton(inputId = "load", label = "Load and transform data"),
                            br(),
                            br(),
                            br(),
                            h5("Navigate to the directory where you want the output
                                           files be stored"),
                            shinyDirButton(id = "folder2",label = "Select output folder",
                                           title =  "Navigate to output folder"),
                            br(),
                            verbatimTextOutput("folder.path.output"),
                            actionButton(inputId = "save", label = "Save"),
                            br(),
                            br(),
                            screenshotButton(filename = "Tab1", label = "Visual log"))),


                   column(10,
                          h5(strong("Example of a dataset name:")),
                          h5("Dataset names should at least include protein name and frame interval;
                               they can include up to 5 different experimental conditions"),
                          verbatimTextOutput("folderpath"),
                          br(),
                          h5(strong("Copy the unique part of dataset name and past it below
                                       (exclude the repeatative suffixes)")),
                          wellPanel(textInput("dataset.name.s",
                                              ""))),
                   column(10, h5(strong("Define the type of the variable each part of the
                                                 dataset name represents"))),
                   column(1, selectInput("pos1", "Position1_",
                                         c("NA" = "remove1", "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(1, selectInput("pos2", "_Position2_",
                                         c("NA" = "remove2", "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(1, selectInput("pos3", "_Position3_",
                                         c("NA" = "remove3", "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(1, selectInput("pos4", "_Position4_",
                                         c("NA" = "remove4", "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(1, selectInput("pos5", "_Position5_",
                                         c( "NA" = "remove5", "protein", "frame.interval",
                                            "expr.cond1",
                                            "expr.cond2",
                                            "expr.cond3",
                                            "expr.cond4",
                                            "expr.cond5"))),
                   column(1, selectInput("pos6", "_Position6_",
                                         c("NA" = "remove6", "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(1, selectInput("pos7", "_Position7",
                                         c("NA" = "remove7" , "protein", "frame.interval",
                                           "expr.cond1",
                                           "expr.cond2",
                                           "expr.cond3",
                                           "expr.cond4",
                                           "expr.cond5"))),
                   column(10,
                          h5(strong("Number of datasets:")),
                          verbatimTextOutput("summary1.1"),
                          h5(strong("Number of frames:")),
                          verbatimTextOutput("summary1.2"),
                          h5(strong("Number of observations:")),
                          verbatimTextOutput("summary1.3"),
                          h5(strong("Detail of datasets:")),
                          dataTableOutput("summary1.4"))
                 )),

        tabPanel(title = "Spatial filtering",
                 fluidRow(
                   column(2,
                          wellPanel(
                            fileInput("file1", label = "File input from tab1", accept = ".rds"),
                            actionButton(inputId = "start", label = "Start"),
                            br(),
                            br(),
                            numericInput("num", label = "Select the dataset", value = 1,
                                         min = 1),
                            br(),
                            br(),
                            h5(strong("Select relevant data points from the plot on the left and
                                         check the result on the right side")),
                            br(),
                            br(),
                            actionButton(inputId = "select", label = "Substrate trace"),
                            br(),
                            br(),
                            actionButton(inputId = "stuck", label = "Surface bound signal"),
                            br(),
                            br(),
                            actionButton(inputId = "split", label = "Split substrate trace"),
                            br(),
                            br(),
                            br(),
                            actionButton(inputId = "next.data.set", "Next dataset"),
                            br(),
                            br(),
                            br(),
                            br(),
                            h5(strong("For repeating the selection for each dataset first
                                         reset the current selection")),
                            actionButton(inputId = "reset", label = "Reset selection"),
                            br()),

                          wellPanel(

                            actionButton(inputId = "intensity", label = "Intensity distribution"),
                            br(),
                            br(),
                            h5(strong("Select an approximate range for intensity; exclude
                                      the extreme values")),
                            numericInput("min.intensity",
                                         "Min intensity",
                                         value = 1),
                            numericInput("max.intensity",
                                         "Max intensity",
                                         value = 10000)),
                          wellPanel(
                          h5("Here is the directory where the output will be stored (can be
                             changed in the first tab):"),
                          br(),
                          verbatimTextOutput("folder.path.output2"),
                          actionButton(inputId = "done", label = "Save"),
                                    br(),
                                    br(),
                                    screenshotButton(filename = "Tab2", label = "Visual log"),
                                    dataTableOutput("summary3"))),
                   h5(strong("Selected data set name:")),
                   verbatimTextOutput("full.name"),
                   column(5, plotOutput("plot1",
                                        brush = "plot_brush")),
                   column(5, plotOutput("plot2")),
                   h5(strong("Progress:")),
                   column(10,
                          dataTableOutput("progress"),
                          br(),
                          br(),
                          br()),
                   column(6,
                          plotOutput("intensity.plot"),
                          br(),
                          br(),
                          br())
                 )),
        tabPanel(title = "Trajectory detection",
                 fluidRow(
                   column(2,
                          wellPanel(fileInput("file2", label = "File input from tab2",
                                              accept = ".rds"),
                                    numericInput("max.dx",
                                                 label = "Max frame-to-frame displacement
                                                 along substrate",
                                                 value = 360),
                                    numericInput("max.dy",
                                                 label = "Max frame-to-frame displacement
                                                 across Substrate",
                                                 value = 240),
                                    numericInput("max.dx.2",
                                                 label = "Localization precision",
                                                 value = 25),

                                    br(),
                                    h5("Define minimum number of frames per trajectories"),
                                    numericInput("min.frame.duration",
                                                 label = "Min trajectory duration",
                                                 value =5),
                                    h5("Define number of trajectories used for optimizing
                                       the noise exclusion model "),
                                    numericInput("trajs.to.inspect",
                                                 label = "Number of trajectories",
                                                 value = 5 ),
                                    br(),

                                    actionButton(inputId = "detect",
                                                 label = "Detect trajectories"),
                                    br(),
                                    br(),

                                    h5("Change the initial values if they are not accepted and press
                                          Re-analize"),

                                    actionButton(inputId = "reanalyse", label = "Re-analyse")),
                          wellPanel(h5(strong("Visualize detected trajectories:")),
                                    br(),
                                    br(),
                                    br(),
                                    br(),
                                    actionButton(inputId = "show", label = "Visualize"),
                                    br(),
                                    br(),
                                    br(),
                                    br(),
                                    numericInput("num2", label = "Select the data set", value = 1,
                                                 min = 1)),
                          wellPanel(br(),
                                    h5("Here is the directory where the output will be stored
                                       (can be changed in the first tab):"),
                                    br(),
                                    verbatimTextOutput("folder.path.output3"),
                                    actionButton(inputId = "save2", label = "Save"),
                                    br(),
                                    br(),
                                    screenshotButton(filename = "Tab3", label = "Visual log"))),
                   h5(strong("Initial output of trajectory detection")),
                   column(10, plotOutput("plot31")),
                   column(10, verbatimTextOutput("eval"),
                          br()),

                   h5(strong("Trajectories to visually inspect vs all trajectories:")),
                   column(6, offset = 1,  plotOutput("plot32"),
                          br(),
                          br(),
                          br()),
                   column(6,  h5(strong("Visualized dataset:"))),
                   br(),
                   br(),
                   column(10, verbatimTextOutput("full.name2")),
                   br(),
                   br(),
                   column(6, offset = 1, plotOutput("plot33")),
                   br()
                 )),
        tabPanel(title = "Visual inspection",
                 fluidRow(
                   column(2,
                          wellPanel(
                            fileInput("file3", label = "File input from tab3", accept = ".rds"),
                            br(),
                            actionButton(inputId = "do.it",
                                         label = "Visualize"),
                            br(),
                            h5("Inspect trajectories and remove artifacts"),
                            br(),
                            numericInput("num41",
                                         label = "Select the dataset",
                                         value = 1, min = 1),
                            numericInput("num42",
                                         label = "Select the trajectory",
                                         value = 1, min = 1),
                            actionButton(inputId = "remove4", label = "Remove"),
                            br(),
                            br(),
                            br(),
                            h5("Here is the directory where the output will be stored (can be
                               changed in the first tab):"),
                            br(),
                            verbatimTextOutput("folder.path.output4"),
                            actionButton(inputId = "save4", label = "Save"),
                            br(),
                            br(),
                            screenshotButton(filename = "Tab4", label = "Visual log"))),
                   h5(strong("Selected dataset:")),
                   verbatimTextOutput("full.name41"),
                   h5(strong("Selected trajectory:")),
                   verbatimTextOutput("full.name42"),
                   column(5, plotOutput("plot41")),
                   column(5, plotOutput("plot42")),
                 )),
        tabPanel(title = "Noise exclusion",
                 fluidRow(
                   column(2,
                          wellPanel(
                            fileInput("file51", label = "File input from tab 1", accept = ".rds"),
                            fileInput("file52", label = "File input from tab 4", accept = ".rds"),
                            actionButton(inputId = "noise.filters", label = "Exclude noise"),
                            checkboxGroupInput("checkGroup", h3("Detected data"),
                                               choices = list("Noise-excluded data" =
                                                                "Noise-excluded data",
                                                              "Surface-bound emitters" =
                                                                "Surface-bound emitters",
                                                              "Non-linear movements" =
                                                                "Non-linear movements",
                                                              "High/low intensity noise" =
                                                                "High/low intensity noise",
                                                              "Short-lived noise" =
                                                                "Short-lived noise"),
                                               selected = "Noise-excluded data"),
                            sliderInput("stuck.gauge", "Surface-bound filter gauge",
                                        min = 0, max = 10,
                                        value = 7),
                            sliderInput("flank.gauge", "Non-linear filter gauge",
                                        min = 0, max = 10,
                                        value = 3),
                            sliderInput("intensity.gauge", "Intensity filter gauge",
                                        min = 0, max = 10,
                                        value = 3),
                            numericInput("num51", label = "Select the data set", value = 1, min = 1)
                          ),
                          wellPanel(
                            h5(strong("Visualize individual trajectories")),
                            actionButton(inputId = "do.it5", label = "Visualize"),
                            br(),
                            br(),
                            numericInput("num52", label = "Select the trajectory id",
                                         value = 1, min = 1),
                            br(),
                            br()
                          ),
                          wellPanel(
                            h5("Here is the directory where the output will be stored (can be
                               changed in the first tab):"),
                            br(),
                            verbatimTextOutput("folder.path.output5"),
                            actionButton(inputId = "save5", label = "Save"),
                            br(),
                            br(),
                            screenshotButton(filename = "Tab5", label = "Visual log")
                          )),
                   column(6, offset = 2, plotOutput("plot51"),
                          plotOutput("plot52"),
                          br(),
                          br(),
                          br()),
                   column(7,plotOutput("plot53")),
                   column(3,plotOutput("plot54"))
                 )),
        tabPanel(title = "Analysis output",
                 fluidRow(
                   column(2,
                          wellPanel(
                            fileInput("file6", label = "File input from tab5", accept = ".rds"),
                            h5("Upload files and press Add one by one"),
                            actionButton(inputId = "add6", label = "Add"),
                            checkboxGroupInput("inCheckboxGroup", "Proteins added", inline = TRUE),
                            selectInput("in.select", "Exprimental conditions",
                                        c("expr.cond1", "expr.cond2"))
                          )),
                   column(10,
                          h5(strong("Overview of the analysed data")),
                          dataTableOutput("datasets"),
                          br(),
                          br()
                   )),
                 h5(strong("Visualization of analysis outputs")),
                 column(12,
                        wellPanel(
                          h5(strong("Scanning speed")),
                          actionButton(inputId = "show60", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup0",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select0", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot60.1")),
                 column(8, plotOutput("plot60.2")),
                 column(1, offset = 3, actionButton(inputId = "save60.1", label = "Save data 1.1")),
                 column(1, offset = 7, actionButton(inputId = "save60.2", label = "Save data 1.2")),
                 column(8, offset = 4, plotOutput("plot60.3")),
                 column(1, offset = 11, actionButton(inputId = "save60.3", label = "Save data 1.3")),

                 column(12,
                        br(),
                        br(),
                        wellPanel(
                          h5(strong("Binding lifetime")),
                          actionButton(inputId = "show61", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup1",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select1", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot61.1")),
                 column(8,plotOutput("plot61.2")),
                 column(1, offset = 3, actionButton(inputId = "save61.1", label = "Save data 2.1")),
                 column(1, offset = 7, actionButton(inputId = "save61.2", label = "Save data 2.2")),

                 column(12,
                        br(),
                        br(),
                        wellPanel(
                          h5(strong("Scanning coverage")),
                          actionButton(inputId = "show62", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup2",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select2", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot62.1")),
                 column(8, plotOutput("plot62.2")),
                 column(1, offset = 3, actionButton(inputId = "save62.1", label = "Save data 3.1")),
                 column(1, offset = 7, actionButton(inputId = "save62.2", label = "Save data 3.2")),

                 column(12,
                        br(),
                        br(),
                        wellPanel(
                          h5(strong("Accumulaitive scanning length")),
                          actionButton(inputId = "show63", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup3",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select3", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot63.1")),
                 column(8, plotOutput("plot63.2")),
                 column(1, offset = 3, actionButton(inputId = "save63.1", label = "Save data 4.1")),
                 column(1, offset = 7, actionButton(inputId = "save63.2", label = "Save data 4.2")),

                 column(12,
                        br(),
                        br(),
                        wellPanel(
                          h5(strong("Redundancy - efficiency analysis")),
                          actionButton(inputId = "show64", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup4",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select4", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot64.1")),
                 column(8, plotOutput("plot64.2")),
                 column(1, offset = 3, actionButton(inputId = "save64.1", label = "Save data 5.1")),
                 column(1, offset = 7, actionButton(inputId = "save64.2", label = "Save data 5.2")),
                 column(8, offset = 4, plotOutput("plot64.3")),
                 column(1, offset = 11, actionButton(inputId = "save64.3", label = "Save data 5.3")),

                 column(12,
                        br(),
                        br(),
                        wellPanel(
                          h5(strong("Diffusion rate analysis")),
                          actionButton(inputId = "show65", label = "Show"),
                          checkboxGroupInput("inCheckboxGroup5",
                                             "Proteins", inline = TRUE),
                          selectInput("in.select5", "Exprimental conditions",
                                      c("expr.cond1", "expr.cond2")))),
                 column(4, plotOutput("plot65.1")),
                 column(8, plotOutput("plot65.2")),
                 column(1, offset = 3, actionButton(inputId = "save65.1", label = "Save data 6.1")),
                 column(1, offset = 7, actionButton(inputId = "save65.2", label = "Save data 6.2")),
                 column(8, offset = 4,  plotOutput("plot65.3")),
                 column(1, offset = 11, actionButton(inputId = "save65.3", label = "Save data 6.3"),
                        br(),
                        br()
                 ),
                 column(1,offset = 11, screenshotButton(filename = "Tab6", label = "Visual log"))


        )
      ))
  )
}

#' Add external Resources to the Application
#'
#' This function is internally used to add external
#' resources inside the Shiny application.
#'
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function() {
  add_resource_path(
    "www",
    app_sys("app/www")
  )

  tags$head(
    favicon(),
    bundle_resources(
      path = app_sys("app/www"),
      app_title = "SMITracker"
    )
    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert()
  )
}
