library(testthat)
library(SMITracker)  # Replace with the actual name of your package

test_that("run_app() works without errors", {
  expect_error(run_app(), NA)
})
